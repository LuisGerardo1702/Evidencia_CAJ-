package repository;

import java.sql.DriverManager;
import java.sql.SQLException;

public class PruebaConexion {
	public static void main(String[]args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			DriverManager.getConnection("jdbc:mysql://localhost:3306/evidencia","root","Luis17022021");
			
			System.out.println("Conexion OK");
			
		} catch (ClassNotFoundException e) {
			System.out.println("Error al cargar el controlador");
			e.printStackTrace();
		}catch(SQLException e) {
			System.out.println("Error en la conexion");
			e.printStackTrace();
		}
	}
}
