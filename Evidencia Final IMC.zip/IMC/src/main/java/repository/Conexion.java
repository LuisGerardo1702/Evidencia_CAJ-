package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {
    private static final Logger logger = Logger.getLogger(Conexion.class.getName());
    private static final String URL = "jdbc:mysql://localhost:3306/evidencia";
    private static final String USER = "root";
    private static final String PASSWORD = "Luis17022021";

    public static Connection getConnection() throws SQLException {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            logger.log(Level.INFO, "Conexión establecida correctamente a la base de datos");
        } catch (ClassNotFoundException e) {
            logger.log(Level.SEVERE, "No se pudo cargar el driver de MySQL", e);
            throw new SQLException("No se pudo cargar el driver de MySQL", e);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error al conectar a la base de datos: " + e.getMessage(), e);
            throw new SQLException("Error al conectar a la base de datos", e);
        }
        return conn;
    }

    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
                logger.log(Level.INFO, "Conexión cerrada correctamente");
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Error al cerrar la conexión: " + e.getMessage(), e);
            }
        }
    }
}
