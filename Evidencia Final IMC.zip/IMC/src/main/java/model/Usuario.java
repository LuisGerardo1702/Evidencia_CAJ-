package model;

public class Usuario {
    private int id;
    private String nombre;
    private String sexo;
    private double estatura;
    private double peso;
    private String nombreUsuario;
    private String contrasena; 
    private double imc;

    public Usuario(String nombre, String sexo, double estatura, double peso, String nombreUsuario, String contrasena, double imc) {
        this.nombre = nombre;
        this.sexo = sexo;
        this.estatura = estatura;
        this.peso = peso;
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.imc = imc;
    }

    public Usuario(int id, String nombre, String sexo, double estatura, double peso, String nombreUsuario, String contrasena, double imc) {
        this.id = id;
        this.nombre = nombre;
        this.sexo = sexo;
        this.estatura = estatura;
        this.peso = peso;
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.imc = imc;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public double getEstatura() {
        return estatura;
    }

    public void setEstatura(double estatura) {
        this.estatura = estatura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public double getImc() {
        return imc;
    }

    public void setImc(double imc) {
        this.imc = imc;
    }
}