package model;

public class IMC {
    private double peso;
    private double estatura;
    private double imc;

    public IMC(double peso, double estatura) {
        this.peso = peso;
        this.estatura = estatura;
        this.imc = calcularIMC();
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getEstatura() {
        return estatura;
    }

    public void setEstatura(double estatura) {
        this.estatura = estatura;
    }

    public double getImc() {
        return imc;
    }

    public void setImc(double imc) {
        this.imc = imc;
    }

    private double calcularIMC() {
        return peso / (estatura * estatura);
    }
}