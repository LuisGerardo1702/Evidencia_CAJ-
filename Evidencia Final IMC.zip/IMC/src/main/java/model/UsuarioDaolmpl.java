package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import repository.Conexion;

public class UsuarioDaolmpl implements UsuarioDAO {
    private final String SQL_SELECT_ALL = "SELECT * FROM evidencia";
    private final String SQL_SELECT_BY_USERNAME = "SELECT * FROM evidencia WHERE Nombre_de_usuario = ?";
    private final String SQL_INSERT = "INSERT INTO evidencia (Nombre, Sexo, Estatura, Peso, Nombre_de_usuario, Contrasena, IMC) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private final String SQL_UPDATE = "UPDATE evidencia SET Nombre = ?, Sexo = ?, Estatura = ?, Peso = ?, Nombre_de_usuario = ?, Contrasena = ?, IMC = ? WHERE Id = ?";
    private final String SQL_DELETE = "DELETE FROM evidencia WHERE Id = ?";

    private Connection obtenerConexion() throws SQLException {
        return Conexion.getConnection();
    }

    @Override
    public List<Usuario> obtenerTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        try (Connection conn = obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_ALL);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Usuario usuario = new Usuario(
                        rs.getInt("Id"),
                        rs.getString("Nombre"),
                        rs.getString("Sexo"),
                        rs.getDouble("Estatura"),
                        rs.getDouble("Peso"),
                        rs.getString("Nombre_de_usuario"),
                        rs.getString("Contrasena"),
                        rs.getDouble("IMC")
                );
                usuarios.add(usuario);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuarios;
    }

    @Override
    public Usuario obtenerPorNombreUsuario(String nombreUsuario) {
        Usuario usuario = null;
        try (Connection conn = obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_USERNAME)) {
            stmt.setString(1, nombreUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    usuario = new Usuario(
                            rs.getInt("Id"),
                            rs.getString("Nombre"),
                            rs.getString("Sexo"),
                            rs.getDouble("Estatura"),
                            rs.getDouble("Peso"),
                            rs.getString("Nombre_de_usuario"),
                            rs.getString("Contrasena"),
                            rs.getDouble("IMC")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuario;
    }

    @Override
    public boolean insertar(Usuario usuario) {
        boolean insertado = false;
        try (Connection conn = obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT)) {
            stmt.setString(1, usuario.getNombre());
            stmt.setString(2, usuario.getSexo());
            stmt.setDouble(3, usuario.getEstatura());
            stmt.setDouble(4, usuario.getPeso());
            stmt.setString(5, usuario.getNombreUsuario());
            stmt.setString(6, usuario.getContrasena());
            stmt.setDouble(7, usuario.getImc());

            int filasInsertadas = stmt.executeUpdate();
            insertado = (filasInsertadas > 0);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return insertado;
    }

    @Override
    public boolean actualizar(Usuario usuario) {
        boolean actualizado = false;
        try (Connection conn = obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE)) {
            stmt.setString(1, usuario.getNombre());
            stmt.setString(2, usuario.getSexo());
            stmt.setDouble(3, usuario.getEstatura());
            stmt.setDouble(4, usuario.getPeso());
            stmt.setString(5, usuario.getNombreUsuario());
            stmt.setString(6, usuario.getContrasena());
            stmt.setDouble(7, usuario.getImc());
            stmt.setInt(8, usuario.getId());

            int filasActualizadas = stmt.executeUpdate();
            actualizado = (filasActualizadas > 0);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return actualizado;
    }

    @Override
    public boolean eliminar(int id) {
        boolean eliminado = false;
        try (Connection conn = obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(SQL_DELETE)) {
            stmt.setInt(1, id);

            int filasEliminadas = stmt.executeUpdate();
            eliminado = (filasEliminadas > 0);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return eliminado;
    }

    public static void main(String[] args) {
        UsuarioDaolmpl dao = new UsuarioDaolmpl();
        List<Usuario> usuarios = dao.obtenerTodos();
        usuarios.forEach(u -> System.out.println(u.getNombre()));
    }
}
