package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Usuario;
import model.UsuarioDAO;
import model.UsuarioDaolmpl;

@WebServlet("/Registro")
public class Registro extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String sexo = request.getParameter("sexo");
        double estatura = Double.parseDouble(request.getParameter("estatura"));
        double peso = Double.parseDouble(request.getParameter("peso"));
        String nombreUsuario = request.getParameter("nombreUsuario");
        String contrasena = request.getParameter("contrasena");
        double imc = calcularIMC(peso, estatura);

        
        Usuario usuario = new Usuario(nombre, sexo, estatura, peso, nombreUsuario, contrasena, imc);

        
        UsuarioDAO usuarioDAO = new UsuarioDaolmpl();
        boolean insertado = usuarioDAO.insertar(usuario);

        if (insertado) {
            
            HttpSession session = request.getSession();
            session.setAttribute("nombreUsuario", nombre);

            response.sendRedirect("CalculoIMC.jsp");
        } else {
        
            response.sendRedirect("Registro.jsp");
        }
    }

    private double calcularIMC(double peso, double estatura) {
       
        return peso / (estatura * estatura);
    }
}